import { IsOptional, IsEnum, IsInt, Min, IsString } from 'class-validator';
import { Type } from 'class-transformer';
import { Category, Gender, Size } from '@prisma/client';

export class FilterProductsDto {

  @IsOptional()
  @IsEnum(Category)
  category?: Category;

  @IsOptional()
  @IsEnum(Gender)
  gender?: Gender;

  @IsOptional()
  @IsString()
  color?: string;

  @IsOptional()
  @IsEnum(Size)
  size?: Size;

  // 🔹 PAGINACIÓN

  @IsOptional()
  @Type(() => Number) // transforma string -> number
  @IsInt()
  @Min(1)
  page?: number = 1;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number = 10;
}