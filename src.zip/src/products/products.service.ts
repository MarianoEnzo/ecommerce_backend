import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateProductDto } from './dto/create-product.dto';
import { FilterProductsDto } from './dto/filter-products.dto';

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  private generateSlug(name: string): string {
    return name
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^\w-]+/g, '');
  }

  // 🔐 Crear producto
  async create(createProductDto: CreateProductDto) {
    const { variants, ...productData } = createProductDto;

    const slug = this.generateSlug(productData.name);

    return this.prisma.product.create({
      data: {
        ...productData,
        slug,
        variants: {
          create: variants.map((v) => ({
            size: v.size,
            stock: v.stock,
            imageUrl: v.imageUrl,
            color: {
              connect: { id: v.colorId },
            },
          })),
        },
      },
      include: {
        variants: {
          include: { color: true },
        },
      },
    });
  }

  // 📦 Listar con filtros + paginación
  async findAll(filters: FilterProductsDto) {
    const page = filters.page ?? 1;
    const limit = filters.limit ?? 10;

    const skip = (page - 1) * limit;

    const whereClause: any = {
      isActive: true,
      category: filters.category,
      gender: filters.gender,
      variants: {
        some: {
          size: filters.size,
          color: filters.color
            ? { name: filters.color }
            : undefined,
        },
      },
    };

    const [products, total] = await this.prisma.$transaction([
      this.prisma.product.findMany({
        where: whereClause,
        skip,
        take: limit,
        include: {
          variants: {
            include: { color: true },
          },
        },
      }),
      this.prisma.product.count({
        where: whereClause,
      }),
    ]);

    return {
      data: products,
      meta: {
        total,
        page,
        lastPage: Math.ceil(total / limit),
      },
    };
  }

  async findOneBySlug(slug: string) {
    const product = await this.prisma.product.findUnique({
      where: { slug },
      include: {
        variants: {
          include: { color: true },
        },
      },
    });

    if (!product) {
      throw new NotFoundException('Product not found');
    }

    return product;
  }
}